const { DataTypes, Model } = require('sequelize');

module.exports = class Assinaturas extends Model {
    static init(sequelize) {
        return super.init({
            id: {
                type: DataTypes.INTEGER,
                autoIncrement: true,
                primaryKey: true
            },
            email: { 
                type: DataTypes.TEXT 
            },
            link: { 
                type: DataTypes.TEXT 
            },
            clicks: { 
                type: DataTypes.TEXT 
            },
        }, {
            tableName: 'Users.Assinaturas',
            timestamps: false,
            sequelize
        });
    }
}