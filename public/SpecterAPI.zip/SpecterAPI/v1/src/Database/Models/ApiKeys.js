const { DataTypes, Model } = require('sequelize');

module.exports = class APIKeys extends Model {
    static init(sequelize) {
        return super.init({
            id: {
                type: DataTypes.INTEGER,
                autoIncrement: true,
                primaryKey: true
            },
            email: { 
                type: DataTypes.TEXT 
            },
            key: { 
                type: DataTypes.TEXT 
            },
            admin: { 
                type: DataTypes.BOOLEAN 
            }
        }, {
            tableName: 'Users_Keys',
            timestamps: true,
            sequelize
        });
    }
}