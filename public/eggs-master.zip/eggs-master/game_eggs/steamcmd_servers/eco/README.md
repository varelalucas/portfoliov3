# Eco
Steam Description  
Eco is a community-based game; the players develop laws, government, and an economy to determine the success of their world. We need extensive playtesting to get the balance of our core features just right. Early Access is the perfect fit for finding an audience for this while also funding additional development.

### Server Ports
Eco requires up to 2 ports

game port (default 3000)
web port (default 3001)


| Port    | default       |
|---------|---------------|
| Game    |     3000      |
| Web     |     3001      |