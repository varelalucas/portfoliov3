# Risk of Rain 2

Escape a chaotic alien planet by fighting through hordes of frenzied monsters – with your friends, or on your own.

## Minimum Specifications
- At least 1GB RAM
- Minimum 4GB hard disk space

## Server Ports

The Risk of Rain 2 server requires a single port for access. Steam Query ports are optional for server listing, which might not always function properly, and as such direct IP connection might be required.

| Port  | default |
|-------|---------|
| Game  | 27015   |
| Query | 27016   |

## Installation Notes

The server will get stuck on the very fist start. Kill and restart it.
