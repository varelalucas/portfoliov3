# Minecraft Proxies

* [Java](/game_eggs/minecraft/proxy/java/)
  * [FlameCord](/game_eggs/minecraft/proxy/java/flamecord)
  * [Travertine](/game_eggs/minecraft/proxy/java/travertine)
  * [TyphoonLimbo](/game_eggs/minecraft/proxy/java/typhoonlimbo)
  * [Velocity](/game_eggs/minecraft/proxy/java/velocity)
  * [VIAaaS](/game_eggs/minecraft/proxy/java/viaaas)
  * [Waterfall](/game_eggs/minecraft/proxy/java/waterfall)
* [Bedrock](/game_eggs/minecraft/proxy/bedrock)
  * [Waterdog PE](/game_eggs/minecraft/proxy/bedrock/waterdogpe)
* [Cross Platform](/game_eggs/minecraft/proxy/cross_platform)
    * [GeyserMC](/game_eggs/minecraft/proxy/cross_platform/geyser)
    * [Waterdog](/game_eggs/minecraft/proxy/cross_platform/waterdog)
