## Technic Eggs

[Technic](/game_eggs/minecraft/java/technic/)
* [Attack of the B-Team](/game_eggs/minecraft/java/technic/attack-of-the-bteam/)
* [Blightfall](/game_eggs/minecraft/java/technic/blightfall/)
* [Hexxit](/game_eggs/minecraft/java/technic/hexxit/)
* [Tekkit](/game_eggs/minecraft/java/technic/Tekkit/)
* [Tekkit Classic](/game_eggs/minecraft/java/technic/tekkit-classic/)
* [Tekkit Legends](/game_eggs/minecraft/java/technic/tekkit-legends/)
* [The 1.7.10 Pack](/game_eggs/minecraft/java/technic/the-1-7-10-pack/)
* [The 1.12.2 Pack](/game_eggs/minecraft/java/technic/the-1-12-2-pack/)
