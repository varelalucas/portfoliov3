# Squad

Squad is an online multiplayer first-person shooter that aims to capture combat realism through communication and teamplay.

### Server Ports
Squad requires 4 ports

| Port     | default |
|----------|---------|
| Game     | 7787    |
| game +1  | 7788    |
| Query    | 27165   |
| Query +1 | 27166   |