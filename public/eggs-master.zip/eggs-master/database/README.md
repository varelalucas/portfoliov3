# databases

## In-Memory Databases
### [redis](/redis/)
    https://redis.io/

## NoSQL
### [mongodb](/nosql/mongodb/)
    https://www.mongodb.com/

## SQL Databases
### [mariadb](/sql/mariadb/)
    https://mariadb.org/

### [postgres](/sql/postgres/)
    https://www.postgresql.org/