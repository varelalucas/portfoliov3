# Code-Server

### From the [Code-Server](https://github.com/cdr/code-server) GitHub

Run [VS Code](https://github.com/Microsoft/vscode) on any machine anywhere and access it in the browser.

### Server Ports

Ports required to run the server in a table format.

| Port | default |
| ---- | ------- |
| Game | 8080    |
