# Quake Live
A first-person shooter video game by id Software. It is an updated version of Quake III Arena that was originally designed 
as a free-to-play game launched via a web browser plug-in. On September 17, 2014, the game was re-launched as a standalone 
title on Steam.

Quake Live was previously a free-to-play game, with subscription options offering additional arenas, game types and game 
server options. As of October 27, 2015, the game is no longer free and must be purchased, and the subscription options 
were dropped.

### Server Ports
Ports required to run the server in a table format.

| Port    | default   |
|---------|-----------|
| Game    | 27960 UDP |
| Stats   | 27960 TCP |
