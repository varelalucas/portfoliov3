# SogeBot
### Their [Site](https://www.sogebot.xyz)
sogeBot is an actively developed open source interactive Twitch bot that provides entertainment and moderation for your channel,
allowing you to focus on what matters the most to you - your game and your viewers.

### Server Ports
1 port is required to run sogeBot.

| Port                | default |
|---------------------|---------|
| Game (HTTP Server)  | 20000   |

#NOTES

The installation take a long time, because a lot of things must be compiled. It can take 5 or more minutes !!!
