# TeamSpeak3 Bots

### Some of these bots support other services but are primarily TeamSpeak3 bots

#### JTS3ServerMod
[JTS3ServerMod](https://www.stefan1200.de/forum/index.php?topic=2.0)  
Please Check their site for an in depth on the bot.