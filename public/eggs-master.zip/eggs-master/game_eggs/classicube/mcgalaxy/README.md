# Classicube MCGalaxy
[MCGalaxy](https://github.com/UnknownShadow200/MCGalaxy) 

MCGalaxy is a fully featured and customisable ClassiCube Server Software based on MCForge/MCLawl.


| Port    | default |
|---------|---------|
| Game    | 25565   |

