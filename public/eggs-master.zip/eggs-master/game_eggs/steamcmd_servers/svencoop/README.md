# Sven Co-op
Sven Co-op is a co-operative game originally based around Valve Software's Half-Life. In this game players must work together against computer controlled enemies and solve puzzles as a team.

### Server Ports
Sven co-op requires a single port to be opened

game ports (default 27015 )

| Port    | default |
|---------|---------|
| Game    |  27015  |
| VAC     |  26900  |
