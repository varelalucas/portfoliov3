## All Minecraft eggs have been migrated to a [new game_eggs folder.](https://github.com/parkervcp/eggs/tree/master/game_eggs/minecraft)

This folder is only kept for backward compatibility for eggs that are downloading server.properties file from here.