const { DataTypes, Model } = require('sequelize');

module.exports = class Faturas extends Model {
    static init(sequelize) {
        return super.init({
            id: {
                type: DataTypes.INTEGER,
                autoIncrement: true,
                primaryKey: true
            },
            email: { 
                type: DataTypes.TEXT 
            },
            link: { 
                type: DataTypes.TEXT 
            },
            preference_id: { 
                type: DataTypes.TEXT 
            },
            state: { 
                type: DataTypes.TEXT 
            },
        }, {
            tableName: 'Users.Faturas',
            timestamps: false,
            sequelize
        });
    }
}