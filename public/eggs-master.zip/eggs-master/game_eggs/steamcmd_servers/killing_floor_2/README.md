# Killing Floor 2
### From their [Site](https://killingfloor2.com/)
In KILLING FLOOR 2, players descend into continental Europe after it has been overrun by horrific, murderous clones called Zeds that were created by the corporation Horzine. The Zed outbreak caused by Horzine Biotech’s failed experiments has quickly spread with unstoppable momentum, paralyzing the European Union. Only a month ago, the first Zed outbreak from the original KILLING FLOOR ripped through London; now the specimen clones are everywhere.

### Server Ports
Ports required to run the server in a table format.

| Port       | default |
|------------|---------|
| Game Port  | 7777    |
| Query Port | 27015   |
|Extra Ports |---------|
| Web Admin  | 8080    |