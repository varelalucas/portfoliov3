# Elasticsearch

### From the [Elasticsearch](https://github.com/elastic/elasticsearch) GitHub

Run [Elasticsearch](https://github.com/elastic/elasticsearch) on any machine anywhere and access it in the browser.

### vm.max_map_count requirement
Please follow this for the vm.max_map_count requirement: https://www.elastic.co/guide/en/elasticsearch/reference/current/docker.html#_set_vm_max_map_count_to_at_least_262144

### Server Ports

Ports required to run the server in a table format.

| Port | default |
| ---- | ------- |
| Game | 9200    |
