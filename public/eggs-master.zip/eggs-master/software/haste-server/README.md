# haste-server
### Their [Github](https://github.com/seejohnrun/haste-server)
Host your own [Hastebin](https://hastebin.com).
### Server Ports
Ports required to run the server in a table format.
| Port | default |
| ---- | ------- |
| Game | 7777    |
