# Grand Theft Auto Connected
The [GTAC](https://gtaconnected.com/) Grand Theft Auto Connected is a custom scriptable multiplayer modification for multiple Grand Theft Auto games.

### Server Ports

GTAC requires one port for both UDP/TCP

| Port    | default  |
|---------|----------|
| Game    | 22000    |