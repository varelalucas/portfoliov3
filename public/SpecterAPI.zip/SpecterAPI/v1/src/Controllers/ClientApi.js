const { Router, urlencoded, json } = require("express");
const { hash, compare } = require("bcrypt")
const jwt = require("jsonwebtoken")
const APIKeys = require("../Database/Models/ApiKeys");
const CoursesUsersTable = require("../Database/Models/CoursesUsersTable");
const Users = require("../Database/Models/UsersTable");

const isValidApiKey = require("../Middlewares/Client/isValidApiKey");

const router = Router()

router.use(json())
router
    .get('/', isValidApiKey, async (req, res) => {
        const findAK = await APIKeys.findOne({
            where: {
                key: req.headers.authorization
            }
        });
    
        if(!findAK) return res.status(401).send("401 | UNAUTHORIZED 1");
        
        const findUser = await Users.findOne({
            where: {
                email: findAK.dataValues.email
            }
        })

        if(!findUser) {
            res.status(401).send("401 | UNAUTHORIZED 2"); 
            findAK.destroy()
        return;
    }

        const courses = []
        
        const findC = await CoursesUsersTable.findAll({
            where: {
                email: findUser.email
            }
        })

        if(findC[0]) {
            findC.map(f => courses.push(f.dataValues))
        }

        const cI = [];
        const cN = [];

        var a = JSON.parse(findUser.dataValues.cargos)

        a.map(v => {
            switch(v) {
                case 1:
                cI.push(1)
                cN.push("CEO")
                break;
                
                case 2:
                cI.push(2)
                cN.push("Diretor")
                break;
                
                case 3:
                cI.push(3)
                cN.push("Gerente")
                break;
                
                case 4:
                cI.push(4)
                cN.push("Moderador")
                break;
                
                case 5:
                cI.push(5)
                cN.push("Social Media Manager")
                break;
                
                case 6:
                cI.push(6)
                cN.push("Desenvolvedor")
                break;
                
                case 7:
                cI.push(7)
                cN.push("Designer")
                break;             
                
                case 8:
                cI.push(8)
                cN.push("Professor")
                break;             
                
                case 9:
                cI.push(9)
                cN.push("Auxiliar")
                break;             
                
                case 10:
                cI.push(10)
                cN.push("Cliente")
                break;             
                
                case 11:
                cI.push(11)
                cN.push("Membro")
                break;             
                
            }
        })


        res.status(200).json({
            email: findUser.dataValues.email,
            username: findUser.dataValues.username,
            discord: findUser.dataValues.discord,
            createdTimestamp: findUser.dataValues.createdAt,
            cargos: {
                ids: cI,
                nomes: cN
            },
            courses
        })

    })
    .get('/auth/verifyAuth', async (req, res) => {
        
        try {
            if(!req.body || !req.body?.email || !req.body?.senha) return res.status(400).send(`400 | BAD REQUEST`);
        
            const findU = await Users.findOne({
                where: {
                    email: req.body.email
                }
            })

            if(!findU) return res.status(401).send({
                success: false,
                code: "SL1003" 
            })

            const isReal = await compare(req.body.senha, findU.senha)
            
            if(!isReal) return res.status(401).send({
                success: false,
                code: "SL1004" 
            })

            var token = makeid()
            var code = jwt.sign(
                {token}
            , '4FlUmzd#6$3AtLl%N7$%Ta&u5', {
                expiresIn: 86400
            })

            const findT = await APIKeys.findOne({
                where: {
                    email: findU.email
                }
            })

            if(findT) findT.destroy()

            APIKeys.create({
                email: findU.email,
                key: token
            })

            res.status(200).send({
                success: true,
                jwt: code
            })

            

        } catch(e) {
            res.status(500).send(e.message)
            console.log(e);
        }     
    })

module.exports = {
    routePath: '/api/dash', 
    router
}

function makeid() {
    var result           = '';
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < 59; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * 
 charactersLength));
   }
   return result;
}