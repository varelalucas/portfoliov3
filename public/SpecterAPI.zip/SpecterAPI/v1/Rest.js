const Express = require ('express');
const Cors = require('cors');
const Glob = require('glob')
const { Collection } = require('@discordjs/collection');
    const app = Express()
    
    app.use(Cors())

    Glob('./src/Controllers/**/*.js', async (err, a) => {
        a.map(v => {
            const Route = require(v);
            app.use(Route.routePath, Route.router)
        })
    })
    
    const APIKeys = require("./src/Database/Models/ApiKeys");
    const Users = require("./src/Database/Models/UsersTable");
    const CoursesUsersTable = require("./src/Database/Models/CoursesUsersTable");

    const users = new Collection()

    setTimeout(() => {
        Users.findAll().then(v => {
            if(v && v[0]) {
                v.map(f => {
                    users.set(f.dataValues.email, f.dataValues)
                })
            }
        })
    }, 3500)
    

module.exports = {
    app,
    users
}