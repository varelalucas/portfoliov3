# Airplane
### From their [Github](https://github.com/TECHNOVE/Airplane)
A stable, optimized and fast Paper fork.


### Minimum RAM warning
Approximately 2048MB


### Server Ports

| Port    | default |
|---------|---------|
| Game    | 25565   |
