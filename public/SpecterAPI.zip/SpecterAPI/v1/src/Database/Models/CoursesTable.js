const { DataTypes, Model } = require('sequelize');

module.exports = class Courses extends Model {
    static init(sequelize) {
        return super.init({
            id: {
                type: DataTypes.INTEGER,
                autoIncrement: true,
                primaryKey: true
            },
            email: { 
                type: DataTypes.TEXT 
            },
            titulo: { 
                type: DataTypes.TEXT 
            },
            descricao: { 
                type: DataTypes.TEXT 
            },
            categoria: { 
                type: DataTypes.INTEGER 
            },
            aulas: { 
                type: DataTypes.INTEGER 
            },
            tempo: { 
                type: DataTypes.TEXT 
            },
            preco: { 
                type: DataTypes.FLOAT 
            },
            link_pagamento: { 
                type: DataTypes.TEXT 
            },
        }, {
            tableName: 'Courses.Index',
            timestamps: false,
            sequelize
        });
    }
}