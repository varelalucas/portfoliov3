# Minecraft PE (bedrock edition)

#### Bedrock
[Minecraft Bedrock Server](https://minecraft.net/en-us/download/server/bedrock/)
The official Minecraft Bedrock (Formerly Minecraft Pocket Edition) server.

#### gomint
[Gomint Bedrock Server](https://github.com/gomint/gomint)
Easy-to-use, highly configurable Minecraft Bedrock Edition  server software with the ability to sustain in a low-resource environment.

#### Nukkit
[Nukkit GitHub](https://github.com/Nukkit/Nukkit)  
Nukkit is a Nuclear-Powered Server Software For Minecraft: Pocket Edition  

#### PocketMine MP
[PocketMine MP](https://github.com/pmmp/PocketMine-MP)  
A server software for Minecraft: Bedrock Edition in PHP  
