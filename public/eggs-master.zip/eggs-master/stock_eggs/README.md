# Stock Pterodactyl eggs

Eggs based on the stock [Pterodactyl eggs](https://github.com/pterodactyl/panel/tree/develop/database/Seeders/eggs).

These are mostly fixes that should make it into the main repo eventually as I pr them over.
