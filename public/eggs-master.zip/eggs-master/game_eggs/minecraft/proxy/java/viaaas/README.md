# VIAaaS
VIAaaS is the Minecraft plugin ViaVersion made standalone as a proxy.

More information is available here: https://github.com/ViaVersion/VIAaaS

## Server Ports
The minecraft server requires a single port for access (default 25565), and one TCP port 25543, to be used for HTTPS and WebSocket connections.

| Port       | default |
|------------|---------|
| Game       | 25565   |
| WS & HTTPS | 25543   |
