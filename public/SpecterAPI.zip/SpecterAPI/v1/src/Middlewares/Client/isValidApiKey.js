const { NextFunction, Request, Response } = require("express");
const APIKeys = require("../../Database/Models/ApiKeys");
const Users = require("../../Database/Models/UsersTable");

/**
 * 
 * @param {Request} req 
 * @param {Response} res 
 * @param {NextFunction} next 
 * @returns 
 */

async function isValidApiKey(req, res, next) {
    if(!req.headers.authorization) return res.status(401).send("401 | UNAUTHORIZED")
    const findAK = await APIKeys.findOne({
        where: {
            key: req.headers.authorization
        }
    });

    if(!findAK) return res.status(401).send("401 | UNAUTHORIZED 1");

    const findUser = await Users.findOne({
        where: {
            email: findAK.dataValues.email
        }
    })

        if(!findUser) {
        res.status(401).send("401 | UNAUTHORIZED 2"); 
        findAK.destroy()
    return;
}
    return next();
}

module.exports = isValidApiKey;