# Multi Theft Auto
[Multi Theft Auto](https://mtasa.com/) is a Open Source Grand Theft Auto: San Andreas Multiplayer modification.

### Server Ports

Multi Theft Auto requires 3 ports.

| Port | Default |
-------|----------
| Game | 22003   |
| http | 22005   |
| ASE  | 22126   |

The ASE port is required to announce the server to the mta server list, this port is always the Game port (22003) +123.
