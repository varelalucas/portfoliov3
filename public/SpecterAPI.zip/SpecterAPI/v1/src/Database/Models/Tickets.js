const { DataTypes, Model } = require('sequelize');

module.exports = class Tickets extends Model {
    static init(sequelize) {
        return super.init({
            id: {
                type: DataTypes.INTEGER,
                autoIncrement: true,
                primaryKey: true
            },
            email: { 
                type: DataTypes.TEXT 
            },
            type: { 
                type: DataTypes.INTEGER 
            },
            resolved: { 
                type: DataTypes.INTEGER 
            },
            messages: { 
                type: DataTypes.TEXT 
            },
            closedBy: { 
                type: DataTypes.TEXT 
            }
        }, {
            tableName: 'Users.Tickets',
            timestamps: true,
            sequelize
        });
    }
}