const { Router, json } = require("express");
const { hash, compare } = require("bcrypt")
const jwt = require("jsonwebtoken")
const APIKeys = require("../Database/Models/ApiKeys");
const CoursesUsersTable = require("../Database/Models/CoursesUsersTable");
const isAdmin = require("../Middlewares/Admin/isAdmin");
const router = Router()
const { Collection } = require("@discordjs/collection")
const Courses = require("../Database/Models/CoursesTable");
const Users = require("../Database/Models/UsersTable");
const Tickets = require("../Database/Models/Tickets");
const Assinaturas = require("../Database/Models/Assinaturas")
const Faturas = require("../Database/Models/Faturas")


router.use(json())
router
    .get('/users', isAdmin, async (req,res) => {
        const CollectionUsers = new Collection();
        const users = await Users.findAll()
        if(req.body && req.body.filter) {
            if(typeof req.body.filter !== "object" || req.body.filter.length === null || req.body.length === 0) return res.status(400).send({
                success: false,
                code: 'AL1001'
            })

            const dados = []
            req.body.filter.sort().map(x => {
                const arr = users.filter(v => v.cargos.includes(x))
                
                if(arr.first()) {
                    var i = 0;
                    arr.forEach(async (findUser) => {
                        i++

                        const courses = []
                        
                        const findC = await CoursesUsersTable.findAll({
                            where: {
                                email: findUser.email
                            }
                        })
                
                        if(findC[0]) {
                            findC.map(f => courses.push(f.dataValues))
                        }
                
                        const cI = [];
                        const cN = [];
                        console.log(findUser);
                        var a = JSON.parse((findUser.cargos.replaceAll('"', '')))
                        console.log("abc");
                        a.map(v => {
                            switch(v) {
                                case 1:
                                cI.push(1)
                                cN.push("CEO")
                                break;
                                
                                case 2:
                                cI.push(2)
                                cN.push("Diretor")
                                break;
                                
                                case 3:
                                cI.push(3)
                                cN.push("Gerente")
                                break;
                                
                                case 4:
                                cI.push(4)
                                cN.push("Moderador")
                                break;
                                
                                case 5:
                                cI.push(5)
                                cN.push("Social Media Manager")
                                break;
                                
                                case 6:
                                cI.push(6)
                                cN.push("Desenvolvedor")
                                break;
                                
                                case 7:
                                cI.push(7)
                                cN.push("Designer")
                                break;             
                                
                                case 8:
                                cI.push(8)
                                cN.push("Professor")
                                break;             
                                
                                case 9:
                                cI.push(9)
                                cN.push("Auxiliar")
                                break;             
                                
                                case 10:
                                cI.push(10)
                                cN.push("Cliente")
                                break;             
                                
                                case 11:
                                cI.push(11)
                                cN.push("Membro")
                                break;             
                                
                            }
                        })
                
                        dados.push({
                            email: findUser.email,
                            username: findUser.username,
                            discord: findUser.discord,
                            createdTimestamp: findUser.createdAt,
                            cargos: {
                                ids: cI,
                                nomes: cN
                            },
                            courses
                        })

                        console.log(i, arr.size);
                        if(i === arr.size) {
                            console.log(dados)
                            res.status(200).send({
                                success: true, 
                                dados
                            })
                        }


                    }) // map da coleção
                }
            })

        } else {        
            var dados = []
        if(users[0]) { 
            var i = 0;
            users.map(async findUser => {
                i++
                console.log(findUser);
                const courses = []
                
                const findC = await CoursesUsersTable.findAll({
                    where: {
                        email: findUser.email
                    }
                })
        
                if(findC[0]) {
                    findC.map(f => courses.push(f.dataValues))
                }
        
                const cI = [];
                const cN = [];
        
                var a = JSON.parse((findUser.cargos.replaceAll('"', '')))
                console.log("abc");
                a.map(v => {
                    switch(v) {
                        case 1:
                        cI.push(1)
                        cN.push("CEO")
                        break;
                        
                        case 2:
                        cI.push(2)
                        cN.push("Diretor")
                        break;
                        
                        case 3:
                        cI.push(3)
                        cN.push("Gerente")
                        break;
                        
                        case 4:
                        cI.push(4)
                        cN.push("Moderador")
                        break;
                        
                        case 5:
                        cI.push(5)
                        cN.push("Social Media Manager")
                        break;
                        
                        case 6:
                        cI.push(6)
                        cN.push("Desenvolvedor")
                        break;
                        
                        case 7:
                        cI.push(7)
                        cN.push("Designer")
                        break;             
                        
                        case 8:
                        cI.push(8)
                        cN.push("Professor")
                        break;             
                        
                        case 9:
                        cI.push(9)
                        cN.push("Auxiliar")
                        break;             
                        
                        case 10:
                        cI.push(10)
                        cN.push("Cliente")
                        break;             
                        
                        case 11:
                        cI.push(11)
                        cN.push("Membro")
                        break;             
                        
                    }
                })
        
                dados.push({
                    email: findUser.email,
                    username: findUser.username,
                    discord: findUser.discord,
                    createdTimestamp: findUser.createdAt,
                    cargos: {
                        ids: cI,
                        nomes: cN
                    },
                    courses
                })
                if(i === users.size) {
                    res.status(200).send({
                        success: true, 
                        dados
                    })
                    console.log(dados);
                }
                })
            }
    }

    })
    .post('/users/create', isAdmin, async (req, res) => {
        var {
            email,
            username,
            discord,
            senha,
            cargos
        } = req.body

        if(!email || !username || !discord || !senha || !cargos || !cargos.startsWith("[") || !cargos.endsWith("]")) return res.status(400).json({
            success: false,
            code: 'AL1001'
        })

        senha = await hash(senha, 3)

        var findU = await Users.findOne({
            where: {
                email
            }
        })
        if(findU) return res.status(400).json({
            success: false,
            code: 'SL1005'
        })
        
        findU = await Users.create({
            email,
            username,
            discord,
            senha,
            cargos,
        })

        const courses = []
                        
        const findC = await CoursesUsersTable.findAll({
            where: {
                email: findU.email
            }
        })

        if(findC[0]) {
            findC.map(f => courses.push(f.dataValues))
        }

        const cI = [];
        const cN = [];

        var a = JSON.parse((findU.cargos.replaceAll('"', '')))

        a.map(v => {
            switch(v) {
                case 1:
                cI.push(1)
                cN.push("CEO")
                break;
                
                case 2:
                cI.push(2)
                cN.push("Diretor")
                break;
                
                case 3:
                cI.push(3)
                cN.push("Gerente")
                break;
                
                case 4:
                cI.push(4)
                cN.push("Moderador")
                break;
                
                case 5:
                cI.push(5)
                cN.push("Social Media Manager")
                break;
                
                case 6:
                cI.push(6)
                cN.push("Desenvolvedor")
                break;
                
                case 7:
                cI.push(7)
                cN.push("Designer")
                break;             
                
                case 8:
                cI.push(8)
                cN.push("Professor")
                break;             
                
                case 9:
                cI.push(9)
                cN.push("Auxiliar")
                break;             
                
                case 10:
                cI.push(10)
                cN.push("Cliente")
                break;             
                
                case 11:
                cI.push(11)
                cN.push("Membro")
                break;             
                
            }
        })

        res.status(200).json({
            email: findU.dataValues.email,
            username: findU.dataValues.username,
            discord: findU.dataValues.discord,
            createdTimestamp: findU.dataValues.createdAt,
            cargos: {
                ids: cI,
                nomes: cN
            },
            courses
        })
    })
    .put('/users/update/mail', async (req, res) => {
        const {
            oldEmail,
            newEmail
        } = req.body;

        if(!oldEmail || !newEmail) return res.status(400).json({
            success: false,
            code: 'AL1001'
        })
        
        const findU = await Users.findOne({
            where: {
                email: oldEmail
            }
        })

        if(!findU) return res.status(400).json({
            success: false,
            code: 'SL1003'
        })

        await findU.update({
            email: newEmail
        })

        const findCourses = await CoursesUsersTable.findAll({
            where: {
                email: newEmail
            }
        })

        if(findCourses[0]) {
            findCourses.map(f => {
                f.update({
                    email: newEmail
                })
            })
        }

        const findApis = await CoursesUsersTable.findAll({
            where: {
                email: newEmail
            }
        })

        if(findApis[0]) {
            findApis.map(f => {
                f.update({
                    email: newEmail
                })
            })
        }

        const findAssinaturas = await Assinaturas.findAll({
            where: {
                email: newEmail
            }
        })

        if(findAssinaturas[0]) {
            findAssinaturas.map(f => {
                f.update({
                    email: newEmail
                })
            })
        }

        const findFaturas = await Faturas.findAll({
            where: {
                email: newEmail
            }
        })

        if(findFaturas[0]) {
            findFaturas.map(f => {
                f.update({
                    email: newEmail
                })
            })
        }

        res.status(204).send()
    })
    .put('/users/update/password', async (req, res) => {
        const {
            email,
            newPassword
        } = req.body;

        if(!email || !newPassword) return res.status(400).json({
            success: false,
            code: 'AL1001'
        })
        
        const findU = await Users.findOne({
            where: {
                email: email
            }
        })

        if(!findU) return res.status(400).json({
            success: false,
            code: 'SL1003'
        })

        await findU.update({
            senha: await hash(newPassword, 5)
        })

        res.status(204).send()
    })
    .delete('/users/delete', isAdmin, async (req, res) => {
        const { email } = req.body;

        if(!email) return res.status(400).json({
            success: false,
            code: 'AL1001'
        })

        const findU = await Users.findOne({
            where: {
                email
            }
        })

        if(!findU) return res.status(200).json({
            success: false,
            code: 'SL1003'
        })

        const findAC = await CoursesUsersTable.findAll({
            where: {
                email
            }
        })

        if(findAC[0]) {
            findAC.map(f => f.destroy())
        }
        res.status(204).send({})
        findU.destroy()
    })
    .get("/courses", isAdmin, async (req, res) => {
        const findC = await Courses.findAll();
        const Cursos = []

        findC.map(f => {
            Cursos.push(f.dataValues)
        });

        res.status(200).json({
            success: true,
            Cursos,
            ...Cursos.length
        })
    })
    .post("/courses/create", isAdmin, async(req, res) => {
        const {
            email,
            titulo,
            descricao,
            categoria,
            aulas,
            tempo,
            preco,
            link_pagamento
        } = req.body

        if(!email || !titulo || !descricao || !categoria || !aulas || !tempo || !preco || !link_pagamento) return res.status(400).json({
            success: false,
            code: 'AL1001'
        })

        const findU = await Users.findOne({
            where: {
                email
            }
        })

        if(!findU) return res.status(400).json({
            success: false,
            code: 'SL1003'
        })

        const findC = await Courses.create({
            email,
            titulo,
            descricao,
            categoria,
            aulas,
            tempo,
            preco,
            link_pagamento
        })

        res.status(200).json({
            success: true,
            ...findC.dataValues
        })

    })
    .delete('/courses/delete', isAdmin, async (req, res) => {
        const id = req.body.id;
        if(!id || isNaN(id)) return res.status(400).json({
            success: false,
            code: 'AL1001'
        })
        
        const findC = await Courses.findOne({
            where: {
                id
            }
        })

        if(!findC) return res.status(200).json({
            success: false,
            code: 'S404'
        })

        const findCA = await CoursesUsersTable.findAll({
            where: {
                cursoId: id
            }
        })
        if(findCA[0]) {
            findCA.map(f => f.destroy())
        }
        findC.destroy()
        res.status(204).send()
    })
    .get('/tickets', isAdmin, async (req, res) => {
        const email = req.body.email;
        if(!email) return res.status(400).json({
            success: false,
            code: "AL1001"
        })
        const findU = await Users.findOne({
            where: {
                email
            }
        })

        if(!findU) return res.status(400).json({
            success: false,
            code: "SL1003"
        })

        var items = {
            open: [],
            closed: []
        }

        
        items["lengthOpen"] = items.open.length
        items["lengthClosed"] = items.closed.length
        items["length"] = (items.open.length + items.closed.length)

        const findT = await Tickets.findAll({
            where: {
                email,
                resolved: false
            }
        })
        const findTR = await Tickets.findAll({
            where: {
                email,
                resolved: true
            }
        })

        if(findTR[0]) {
            findTR.map(f => {
                items.closed.push({ ...f.dataValues,  type: f.dataValues.type.toString().replace("1", "Administrativo").replace("2", "Financeiro").replace("3", "Técnico").replace("4", "RH").replace("5", "Dúvidas") })
            })
        }
        if(findT[0]) {
            findT.map(f => {
                items.open.push({ ...f.dataValues,  type: f.dataValues.type.toString().replace("1", "Administrativo").replace("2", "Financeiro").replace("3", "Técnico").replace("4", "RH").replace("5", "Dúvidas") })
            })
        }

        res.status(200).send({
            success: true,
            items,
            
        })
        
        
        
    })
    .post('/tickets/create', isAdmin, async (req, res) => {
        const {
            email,
            type
        } = req.body

        if(!email || !type || typeof type !== "number" || type < 1 || type > 4) return res.status(400).json({
            success: false,
            code: "AL1001"
        })

        const findUser = await Users.findOne({
            where: {
                email
            }
        })

        if(!findUser) return res.status(400).send({
            success: false,
            code: "SL1003"
        })

        const findT = await Tickets.create({
            email,
            type,
            resolved: false
        });

        res.status(200).json({
            success: true,
            data: {
                ...findT.dataValues,
                type: findT.type.toString().replace("1", "Administrativo").replace("2", "Financeiro").replace("3", "Técnico").replace("4", "RH").replace("5", "Dúvidas")
            }
        })
        
    })
    .get('/tickets/:ticketId/messages', isAdmin, async (req, res) => {
        const ticketId = req.params.ticketId

        const findT = await Tickets.findOne({
            where: {
                id: ticketId
            }
        })

        if(!findT) return res.status(404).send('404 - Page Not Found')

        const messages = JSON.parse(findT.messages);

        res.status(200).send({
            success: true,
            author: findT.email,
            closed: JSON.parse(findT.resolved.toString().replace(0, false).replace(1, true)),
            type: findT.dataValues.type.toString().replace("1", "Administrativo").replace("2", "Financeiro").replace("3", "Técnico").replace("4", "RH").replace("5", "Dúvidas"),
            messages
        })
    })
    .post('/tickets/:ticketId/messages', isAdmin, async (req, res) => {
        const ticketId = req.params.ticketId

        const {
            author,
            message
        } = req.body
        
        if(!author || !message) return res.status(400).send({
            success: false,
            code: 'AL1001'
        })

        const findU = await Users.findOne({
            where: {
                email: author
            }
        })

        if(!findU) return res.status(400).json({
            success: false,
            code: 'SL1003'
        })

        const findT = await Tickets.findOne({
            where: {
                id: ticketId
            }
        })
        if(!findT) return res.status(404).send('404 - Page Not Found')
        
        const messages = JSON.parse(findT.messages);

        let d = new Date();

// formatar data no formato ISO 8601
var createdTimestamp = d.getFullYear().toString() + "-"+(d.getMonth() + 1).toString().padStart(2, '0') + "-" + d.getDate().toString().padStart(2, '0') + "T" + d.getHours().toString().padStart(2, '0') + ":" + d.getMinutes().toString().padStart(2, '0') + ":" + d.getSeconds().toString().padStart(2, '0');
console.log(createdTimestamp);

        messages.push({
            author,
            message,
            createdTimestamp
        })

        findT.update({
            messages: JSON.stringify(messages)
        })

        res.status(200).send({
            success: true,
            author: findT.email,
            closed: JSON.parse(findT.resolved.toString().replace(0, false).replace(1, true)),
            type: findT.dataValues.type.toString().replace("1", "Administrativo").replace("2", "Financeiro").replace("3", "Técnico").replace("4", "RH").replace("5", "Dúvidas"),
            messages
        })
    })
    .put('/tickets/:ticketId', isAdmin,  async (req, res) => {
        const ticketId = req.params.ticketId
        const {
            email,
            type,
            resolved,
            closedBy
        } = req.body
        
        if(!email || !type || !resolved || resolved == true && !closedBy) return res.status(400).send({
            success: false,
            code: 'AL1001'
        })

        const findT = await Tickets.findOne({
            where: {
                id: ticketId
            }
        })

        if(!findT) return res.status(404).send('404 - Page Not Found')

            const findU = await Users.findOne({
                email
            })

            if(!findU) return res.status(400).send({
                success: false,
                code: 'SL1003'
            })

            if(email === findT.email) return res.status(400).send({
                success: false,
                code: 'AL1001'
            })
        
        if(isNaN(type)) return res.status(400).send({
            success: false,
            message: 'type need number type'
        })
            await findT.update({
                type
            })
        if(typeof resolved !== Boolean) return res.status(400).send({
            success: false,
            message: 'resolved need Boolean type'
        })
            await findT.update(resolved)
        
        if(closedBy) {
            const findC = await Users.findOne({
                where: {
                    email: closedBy
                }
            })
    
            if(!findC) return res.status(400).send({
                success: false,
                code: 'SL1003'
            })
                await findT.update({
                    closedBy
                })
        }
        

        res.status(204).send()
        
    })
    .delete('/ticets/delete', async (req, res) => {
        const {
            id
        } = req.body;

        if(!id) return res.status(400).json({
            success: false,
            code: "AL1001"
        })

        const findT = await Tickets.findOne({
            where: {
                id
            }
        })

        if(!findT) return res.status(404).json({
            success: false,
            code: "S404"
        })

        await findT.destroy();

        res.status(204).send()
        
    })
    


module.exports = {
    routePath: '/api/application', 
    router
}