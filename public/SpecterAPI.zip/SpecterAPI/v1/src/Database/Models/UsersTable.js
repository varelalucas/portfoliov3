const { DataTypes, Model } = require('sequelize');

module.exports = class Users extends Model {
    static init(sequelize) {
        return super.init({
            id: {
                type: DataTypes.INTEGER,
                autoIncrement: true,
                primaryKey: true
            },
            email: { 
                type: DataTypes.TEXT 
            },
            username: { 
                type: DataTypes.TEXT 
            },
            discord: { 
                type: DataTypes.TEXT 
            },
            senha: { 
                type: DataTypes.TEXT 
            },
            cargos: { 
                type: DataTypes.JSON 
            },
        }, {
            tableName: 'UsersTable',
            timestamps: true,
            sequelize
        });
    }
}