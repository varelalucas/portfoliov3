# CryoFall

##Minimum RAM warning
You may want to assign a minimum of 1GB of RAM to a server.

##Required Server Ports
The default is 6000 can be changed in SettingsServer.xml

| Port    | default |
|---------|---------|
| Game    | 6000    |

#### Plugins may require ports to be added to the server.
