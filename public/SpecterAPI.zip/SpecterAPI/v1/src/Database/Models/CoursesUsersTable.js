const { DataTypes, Model } = require('sequelize');

module.exports = class CoursesUsersTable extends Model {
    static init(sequelize) {
        return super.init({
            id: {
                type: DataTypes.INTEGER,
                autoIncrement: true,
                primaryKey: true
            },
            email: { 
                type: DataTypes.TEXT 
            },
            cursoId: { 
                type: DataTypes.TEXT 
            },
            preco: {
                type: DataTypes.FLOAT
            },
            preference_id: { 
                type: DataTypes.TEXT 
            },
        }, {
            tableName: 'Courses.Users',
            timestamps: false,
            sequelize
        });
    }
}