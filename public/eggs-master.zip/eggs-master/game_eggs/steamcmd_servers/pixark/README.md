# PixARK

Welcome to PixARK, a vast, wild world filled with vicious dinosaurs, magical creatures and endless adventure! To survive in this mysterious land, you must tame creatures both ferocious and cuddly, craft high tech and magical tools, and build your own base out of cubes.

### Server Ports
PixARK requires 4 ports

| Port  | default |
|-------|---------|
| Game  | 27015   |
| Query | 27016   |
| RCON  | 27017   |
| cube  | 27018   |