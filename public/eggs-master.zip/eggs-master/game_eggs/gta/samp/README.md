# SA:MP
The [SA:MP](https://www.sa-mp.com/) GTA San Andreas dedicated server