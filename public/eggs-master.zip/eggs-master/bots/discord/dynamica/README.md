# Dynamica

### Their [Github](https://github.com/dynamicabot/dynamica)

This is a discord bot for dynamically managing voice channels.
