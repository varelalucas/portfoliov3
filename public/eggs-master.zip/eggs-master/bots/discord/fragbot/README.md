# fragbot
### Their [Github](https://github.com/fragforce/fragbot)
The golang based discord bot for fragforce. 

Runs the fragforce `@fragbot`

### Server Ports
There are no ports required for fragbot