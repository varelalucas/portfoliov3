# Minecraft Java Proxies


#### FlameCord
[FlameCord](https://github.com/2lstudios-mc/FlameCord)
FlameCord is a patch for Travertine to fix possible exploits and add useful functionalities.

#### Travertine
[Travertine](https://papermc.io/downloads#Travertine)
Waterfall, with additional support for Minecraft 1.7.10. 

#### TyphoonLimbo
[TyphoonLimbo](https://github.com/TyphoonMC/TyphoonLimbo)
A limbo server is a fallback server able to handle a massive amount of simultaneous connections. The player spawns into the void then waits here. It can be used to keep players connected to a network after a lobby crashed or as an afk server.

#### Velocity
[Velocity](https://velocitypowered.com)
Velocity is a Minecraft server proxy with unparalleled server support, scalability, and flexibility. 

#### VIAaaS
[VIAaaS](https://github.com/ViaVersion/VIAaaS) is the Minecraft plugin ViaVersion made standalone as a proxy.

#### Waterfall
[Waterfall](https://papermc.io/downloads#Waterfall)
Paper fork of the BungeeCord software, with improved Forge support and more features.