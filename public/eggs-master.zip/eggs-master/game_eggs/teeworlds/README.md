# Teeworlds
### From their [Site](https://www.teeworlds.com/)
Teeworlds is a free online multiplayer game, available for all major operating systems. Battle with up to 16 players in a variety of game modes, including Team Deathmatch and Capture The Flag. You can even design your own maps

### Server Ports
Ports required to run the server in a table format.

| Port    | default |
|---------|---------|
| Game    | 8303    |
