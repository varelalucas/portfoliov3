# Purpur

Purpur is a fork of Paper and Tuinity which provides new configuration options.

See https://github.com/pl3xgaming/purpur for additional information.

## Server Ports
The minecraft server requires a single port for access (default 25565) but plugins may require extra ports to enabled for the server.


| Port  | default |
|-------|---------|
| Game  | 25565   |