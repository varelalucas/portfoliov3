const { app, users } = require("./Rest");
const Connector = require("./src/Database/Connector");
const glob = require("glob");
const Users = require("./src/Database/Models/UsersTable");

app.listen(3333, () => {
    console.log('[V1] API Iniciada.');
    Connector.authenticate().then(() => {
        console.log('[DB] Iniciada com sucesso.');

        glob('./src/Database/Models/*.js', (err, r) => {
            r.map(f => {
                const b = require(f);
                b.init(Connector)
                if(f.includes("Tickets")) {
                    b.sync({force: false})
                } else {
                    b.sync({force: false})
                }
            })
        })        
    })

})