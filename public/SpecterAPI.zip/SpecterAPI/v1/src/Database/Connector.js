const { Sequelize } = require("sequelize")

module.exports = new Sequelize({
    host: "135.148.144.74",
    port: 3306,
    username: "koddy",
    password: "g%1ic4X1",
    database: "koddy",
    dialect: 'mysql'
})